//
//  CartViewModel.swift
//  RoyalFurnitures
//
//  Created by Amutha on 29/11/25.
//

class CartViewModel {
    
}
