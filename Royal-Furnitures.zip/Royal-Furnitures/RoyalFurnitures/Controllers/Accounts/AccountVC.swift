//
//  AccountVC.swift
//  RoyalFurnitures
//
//  Created by CIPL on 08/11/25.
//

import UIKit

class AccountVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
