//
//  UIApplication+Extension.swift
//  TemployMe
//
//  Created by A2 MacBook Pro 2012 on 04/12/21.
//

import UIKit

extension UIApplication {
    var keywindow: UIWindow? {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        return appDelegate?.window
    }
    
    func setRoot(vc: UIViewController) {
        keywindow?.rootViewController = vc
    }
    var statusBarView: UIView? {
        return value(forKey: "statusBar") as? UIView
    }
}


